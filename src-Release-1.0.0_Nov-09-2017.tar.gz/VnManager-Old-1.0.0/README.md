# VnManager
A program to keep track of your visual novels

| | Active Integrations |
| --- | --- |
**Build Status** | ![Main CI](https://github.com/micah686/VnManager/workflows/Main%20CI/badge.svg)
**Quality (SonarCloud) (Loose Restrictions)** | [![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=c0eb5fc2abd174c0ea9db268ae3de46dd621775d&metric=alert_status)](https://sonarcloud.io/dashboard?id=c0eb5fc2abd174c0ea9db268ae3de46dd621775d)
**History** | [![Build history](https://buildstats.info/github/chart/micah686/VnManager)](https://buildstats.info/github/chart/micah686/VnManager)


| | Repository Info |
| --- | --- |
**Repo Size** | ![Repo Size](https://img.shields.io/github/repo-size/micah686/vnManager)
**Commit Frequency** | ![Commits](https://img.shields.io/github/commit-activity/w/micah686/VnManager)
**Chat** | [![Gitter Chat](https://badges.gitter.im/micah686/VnManager.svg)](https://gitter.im/micah686/VnManager) |




### Please note that all work on v2 of the program has ceased (Visual-Novel-Manager-v2) 

The application is being completely redesinged, using new frameworks.


