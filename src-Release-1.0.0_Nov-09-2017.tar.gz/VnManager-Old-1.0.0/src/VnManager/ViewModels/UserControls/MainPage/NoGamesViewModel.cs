﻿using System;
using System.Collections.Generic;
using System.Text;
using Stylet;

namespace VnManager.ViewModels.UserControls.MainPage
{
    public class NoGamesViewModel: Screen
    {
    }
}
