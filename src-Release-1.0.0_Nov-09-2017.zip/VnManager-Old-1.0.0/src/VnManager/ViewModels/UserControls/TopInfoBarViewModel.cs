﻿using Stylet;
using System;
using System.Collections.Generic;
using System.Text;

namespace VnManager.ViewModels.UserControls
{
    public class TopInfoBarViewModel: Screen
    {
        public TopInfoBarViewModel() { }
    }
}
